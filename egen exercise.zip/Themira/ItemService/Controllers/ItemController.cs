﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ItemService.Controllers
{
	[ApiController]
	[Route("[controller]")]
	public class ItemController : ControllerBase
	{
		private static readonly Item[] sampleItems = new[] {
				new Item {
				Id = Guid.NewGuid(),
				Name = "Item1",
				Price = 3.5f
			}
		};

		private readonly ItemContext _context;
		private readonly ILogger<ItemController> _logger;

		public ItemController(ILogger<ItemController> logger, ItemContext context)
		{
			_logger = logger;
			_context = context;
		}

		[HttpGet]
		public async Task<IEnumerable<Item>> Get()
		{
			Item[] items = await Task.FromResult(_context?.Items.ToArray());
			//return items ?? new Item[] { };
			return await Task.FromResult(sampleItems);
		}

		[HttpPut]
		public async Task Put(params Item[] items)
		{
			await _context?.AddRangeAsync(items);
		}
	}
}